document.addEventListener('DOMContentLoaded', () => {
    // --- Theme Switcher Logic ---
    const themeToggle = document.getElementById('theme-toggle');
    const body = document.body;

    const applyTheme = (theme) => {
        if (theme === 'dark') {
            body.classList.add('dark-mode');
            themeToggle.checked = true;
        } else {
            body.classList.remove('dark-mode');
            themeToggle.checked = false;
        }
    };

    const savedTheme = localStorage.getItem('theme') || 'dark';
    applyTheme(savedTheme);

    themeToggle.addEventListener('change', () => {
        if (themeToggle.checked) {
            localStorage.setItem('theme', 'dark');
            applyTheme('dark');
        } else {
            localStorage.setItem('theme', 'light');
            applyTheme('light');
        }
    });


    // --- NEW: Table Visibility Toggle Logic ---
    const tableToggle = document.getElementById('table-toggle');
    const tableContainer = document.getElementById('table-container');

    const applyTableVisibility = (visibility) => {
        if (visibility === 'shown') {
            tableContainer.style.display = 'block';
            tableToggle.checked = true;
        } else {
            tableContainer.style.display = 'none';
            tableToggle.checked = false;
        }
    };

    const savedVisibility = localStorage.getItem('tableVisibility') || 'shown';
    applyTableVisibility(savedVisibility);

    tableToggle.addEventListener('change', () => {
        if (tableToggle.checked) {
            localStorage.setItem('tableVisibility', 'shown');
            applyTableVisibility('shown');
        } else {
            localStorage.setItem('tableVisibility', 'hidden');
            applyTableVisibility('hidden');
        }
    });
});