document.addEventListener('DOMContentLoaded', function() {
    // --- 1. Toggle Table Visibility ---
    const tableToggle = document.getElementById('table-toggle');
    const tableContainer = document.getElementById('table-container');

    if (tableToggle && tableContainer) {
        function updateTableVisibility() {
            if (tableToggle.checked) {
                tableContainer.classList.remove('d-none');
            } else {
                tableContainer.classList.add('d-none');
            }
        }
        updateTableVisibility();
        tableToggle.addEventListener('change', updateTableVisibility);
    }

    // --- 2. Dynamic Text Rotator ---
    const statusTextElem = document.getElementById('dynamic-status');
    
    if (statusTextElem) {
        // Daftar pesan (Semua akan menjadi link ke wr4ma.github.io)
        const messages = [
            "made with ❤️ by wr4ma", 
            "Click here for another Cool Project"
        ];
        
        let msgIndex = 0;
        const targetUrl = "https://wr4ma.github.io";

        // Fungsi untuk mengatur konten dengan link
        const setContent = (text) => {
             statusTextElem.innerHTML = `<a href="${targetUrl}" target="_blank" class="status-link">${text}</a>`;
        };

        // Inisialisasi pesan pertama
        setContent(messages[0]);
        
        setInterval(() => {
            // Animasi Keluar (Fade Out via class CSS)
            statusTextElem.classList.add('fade-out');
            
            setTimeout(() => {
                // Ganti Konten
                msgIndex = (msgIndex + 1) % messages.length;
                setContent(messages[msgIndex]);
                
                // Animasi Masuk (Hapus class fade-out)
                statusTextElem.classList.remove('fade-out');
            }, 500); // Waktu ini harus sesuai dengan transition di CSS (0.5s)
            
        }, 4000); // Ganti teks setiap 4 detik
    }
});