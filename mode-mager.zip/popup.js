import analytics from "./js/google-analytics.js";

// --- KONFIGURASI ---
// Menggunakan URL baru untuk database user
const DB_URL = 'https://raw.githubusercontent.com/wr4ma/ModeMager/refs/heads/main/wr_check.json';
const VERSION_URL = 'https://raw.githubusercontent.com/wr4ma/ModeMager/refs/heads/main/ver.wr'; // URL Versi
const UPDATE_PAGE_URL = 'https://wr4ma.github.io/'; // URL Tujuan Update
const AUTH_KEY = 'modeMagerAuthSession';

function waitForNetworkIdle(onIdle, onReady, tabId, maxWait, minWait, crawlDelay, onTabReadyCheck) {
    let requests = {};
    let lastRequestTimestamp = null;
    let isIdle = false;
    let isReadyFired = false;
    const filter = {
        urls: ["<all_urls>"],
        tabId: tabId,
        types: ["main_frame", "sub_frame", "stylesheet", "script", "font", "object", "xmlhttprequest", "other"]
    };

    function checkIdle() {
        if (isIdle || !isReadyFired) return;
        (onTabReadyCheck || ((callback) => callback(true)))(isTabReady => {
            if (!isTabReady) return performIdleCheck();
            if (isIdle) return;

            isIdle = true;
            chrome.webRequest.onBeforeRequest.removeListener(handleRequestStart);
            chrome.webRequest.onCompleted.removeListener(handleRequestEnd);
            chrome.webRequest.onErrorOccurred.removeListener(handleRequestEnd);
            onIdle();
        });
    }

    function handleRequestStart(details) {
        requests[details.requestId] = 1;
        lastRequestTimestamp = new Date();
    }

    function handleRequestEnd(details) {
        if (!lastRequestTimestamp) return;
        delete requests[details.requestId];
        if (Object.keys(requests).length === 0) {
            performIdleCheck();
        }
    }

    function performIdleCheck() {
        setTimeout(() => {
            const timeSinceLastRequest = new Date() - lastRequestTimestamp;
            if (timeSinceLastRequest < minWait || Object.keys(requests).length > 0) return;
            checkIdle();
        }, minWait);
    }

    chrome.webRequest.onBeforeRequest.addListener(handleRequestStart, filter);
    chrome.webRequest.onCompleted.addListener(handleRequestEnd, filter);
    chrome.webRequest.onErrorOccurred.addListener(handleRequestEnd, filter);

    (onReady || (() => {}))(() => {
        setTimeout(checkIdle, maxWait);
        setTimeout(() => {
            isReadyFired = true;
            performIdleCheck();
        }, crawlDelay);
    });
}

function dateToExcelSerial(date, isUtc) {
    if (isUtc) {
        date += 1462;
    }
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    return (Date.parse(date) - excelEpoch) / 86400000;
}

function dataToSheet(data) {
    const sheet = {};
    const range = { s: { c: 1e7, r: 1e7 }, e: { c: 0, r: 0 } };

    for (let R = 0; R !== data.length; ++R) {
        for (let C = 0; C !== data[R].length; ++C) {
            if (range.s.r > R) range.s.r = R;
            if (range.s.c > C) range.s.c = C;
            if (range.e.r < R) range.e.r = R;
            if (range.e.c < C) range.e.c = C;

            const cell = { v: data[R][C] };
            if (cell.v === null) continue;

            const cell_ref = XLSX.utils.encode_cell({ c: C, r: R });
            if (typeof cell.v === 'number') {
                cell.t = 'n';
            } else if (typeof cell.v === 'boolean') {
                cell.t = 'b';
            } else if (cell.v instanceof Date) {
                cell.t = 'n';
                cell.z = XLSX.SSF._table[14];
                cell.v = dateToExcelSerial(cell.v);
            } else {
                cell.t = 's';
            }
            sheet[cell_ref] = cell;
        }
    }

    if (range.s.c < 1e7) {
        sheet['!ref'] = XLSX.utils.encode_range(range);
    }
    return sheet;
}

function createWorkbook(jsonData, sheetName) {
    jsonData.data.unshift(jsonData.fields);
    const workbook = new (function Workbook() {
        if (!(this instanceof Workbook)) return new Workbook();
        this.SheetNames = [];
        this.Sheets = {};
    })();
    const worksheet = dataToSheet(jsonData.data);
    workbook.SheetNames.push(sheetName);
    workbook.Sheets[sheetName] = worksheet;
    return XLSX.write(workbook, { type: 'binary' });
}

function tryCatch(fn) {
    try {
        fn();
    } catch (err) {
        console.log("Error: ", err);
    }
}

const tabInfo = {
    id: parseInt(getUrlParameter("tabid")),
    url: getUrlParameter("url")
};
let appState = {};
const PREVIEW_ROW_LIMIT = 1000;
let robots = null;

async function initializeApp() {
    if (tabInfo.url.toLowerCase().match(/\/\/[a-z]+\.linkedin\.com/)) {
        $("#waitHeader").hide();
        displayMessage("We're unable to collect data from LinkedIn. Sorry for the inconvenience.", "noResponseErr", false, true);
        return;
    }

    initializeEventHandlers();
    setTimeout(() => {
        if ($("#waitHeader").is(":visible")) {
            showTimeoutError(true);
        }
    }, 50000);

    $(window).resize(() => renderPreviewTable());
    findInitialTables();
}

function escapeCssSelector(str, prefix) {
    return (prefix || ".") + str.replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\$&");
}

function getUrlParameter(name) {
    const params = new URLSearchParams(window.location.search);
    return decodeURIComponent(params.get(name) || "");
}

function displayMessage(message, elementId, logToAnalytics, isError) {
    if (message === "") {
        $("#" + elementId).hide();
        return;
    }
    $("#" + elementId).show().text(message);
    if (logToAnalytics) stopScraping(message);
    if (isError) {
        analytics.fireEvent("Error", { url: appState.startingUrl || tabInfo.url, msg: message });
    }
}

function processRawDataToColumns(rawData) {
    const totalRows = rawData.length;
    const selectorLengths = {};
    const fieldCounts = {};
    const columnGroups = {};
    const columnPaths = {};
    const fieldScores = {};

    function getSelectorLength(selector) {
        if (selector in selectorLengths) return selectorLengths[selector];
        selectorLengths[selector] = $(escapeCssSelector(selector)).length;
        return selectorLengths[selector];
    }

    rawData.forEach(row => {
        for (const path in row) {
            fieldCounts[path] = (fieldCounts[path] || 0) + 1;
        }
    });

    Object.keys(fieldCounts).map(path => [fieldCounts[path], path]).forEach(([count, path]) => {
        let bestHeader = "";
        let minLength = Infinity;

        path.split(" ")[0].split("/").slice(1).reverse().forEach(part => {
            part.split(".").slice(1).forEach(cls => {
                if (minLength < 2 * totalRows) return;
                const len = getSelectorLength(cls);
                if (len < minLength) {
                    bestHeader = cls;
                    minLength = len;
                }
            });
        });

        const modifier = path.split(" ")[1];
        const isModifierTextual = modifier && isNaN(modifier);
        if (isModifierTextual) {
            bestHeader += " " + modifier;
        }

        const isRowPresent = rawData.map(row => path in row);
        let groupIndex = 0;

        if (bestHeader in columnGroups) {
            const existingGroups = columnGroups[bestHeader];
            let foundGroup = false;
            for (let i = 0; i < existingGroups.length; i++) {
                const group = existingGroups[i];
                let isDisjoint = true;
                group.forEach((val, idx) => {
                    isDisjoint &= !(isRowPresent[idx] && val);
                });
                if (isDisjoint) {
                    foundGroup = true;
                    groupIndex = i + 1;
                    break;
                }
            }

            if (foundGroup) {
                columnGroups[bestHeader][groupIndex - 1] = columnGroups[bestHeader][groupIndex - 1].map((val, idx) => isRowPresent[idx] || val);
            } else {
                columnGroups[bestHeader].push(isRowPresent);
                groupIndex = columnGroups[bestHeader].length;
            }

            if (groupIndex > 1) {
                bestHeader += " " + groupIndex;
            }
        } else {
            columnGroups[bestHeader] = [isRowPresent];
        }

        if (!(bestHeader in columnPaths)) columnPaths[bestHeader] = [];
        columnPaths[bestHeader].push(path);

        if (!(bestHeader in fieldScores)) fieldScores[bestHeader] = 0;
        fieldScores[bestHeader] += count;
    });

    const uniqueFieldCheck = {};
    const finalFields = Object.keys(columnPaths).filter(header => {
        if (header in appState.config.deletedFields) return false;

        const values = [];
        const valueCounts = {};
        rawData.map(row => {
            let value;
            for (let i = 0; i < columnPaths[header].length; i++) {
                const path = columnPaths[header][i];
                if (path in row) {
                    value = row[path];
                    valueCounts[value] = (valueCounts[value] || 0) + 1;
                }
            }
            values.push(value);
        });

        if (Object.keys(valueCounts).length && valueCounts[Object.keys(valueCounts)[0]] === totalRows) {
            return false;
        }

        const valuesString = JSON.stringify(values);
        if (valuesString in uniqueFieldCheck) {
            return false;
        } else {
            uniqueFieldCheck[valuesString] = 1;
            return !(fieldScores[header] < 0.2 * totalRows);
        }
    });

    const result = {
        fields: finalFields,
        data: rawData.map(row => {
            return finalFields.map(header => {
                for (let i = 0; i < columnPaths[header].length; i++) {
                    const path = columnPaths[header][i];
                    if (path in row) return row[path];
                }
                return "";
            });
        })
    };

    appState.names = finalFields;
    appState.namePaths = columnPaths;
    return result;
}

function applyCustomHeaders(fields) {
    return fields.map(field => field in appState.config.headers ? appState.config.headers[field] : field);
}

function prepareDataForDisplay(data) {
    const processedData = processRawDataToColumns(data);
    processedData.fields = applyCustomHeaders(processedData.fields);
    return processedData;
}

function stringToArrayBuffer(str) {
    const buf = new ArrayBuffer(str.length);
    const bufView = new Uint8Array(buf);
    for (let i = 0; i !== str.length; ++i) {
        bufView[i] = str.charCodeAt(i) & 0xFF;
    }
    return buf;
}

function fireDownloadAnalytics() {
    analytics.fireEvent("Download", {
        hostName: appState.hostName,
        startingUrl: appState.startingUrl,
        dataLength: appState.data.length
    });
    
    (() => {
        let buildSelectorPayload = selectors => {
            let payload = {};
            for (let i = 0; i < 4; i++) {
                payload[`selector${i}`] = selectors[i] !== undefined ? selectors[i] : "";
            }
            return payload;
        };
        
        const headerCount = Object.keys(appState.config.headers).length;
        if (!headerCount) return;

        generateSelectorsForFields(true).then(result => {
            let [rowSelector, fieldSelectors] = result;
            const findField = field_id => fieldSelectors.find(f => f.field_id === field_id);

            let commonPayload = {
                tableId: appState.tableId,
                hostName: appState.hostName,
                startingUrl: appState.startingUrl
            };
            
            if (headerCount) {
                for (const name in appState.config.headers) {
                    let field = findField(appState.config.headers[name]);
                    let selectors = field.selector.split(",").map(s => s.slice(-100));
                    let eventPayload = Object.assign(buildSelectorPayload(selectors), commonPayload, {
                        originalName: name,
                        newName: appState.config.headers[name]
                    });
                    analytics.fireEvent("RenameColumn", eventPayload);
                }
            }
        });
    })();
}

function renderPreviewTable() {
    let processedData = processRawDataToColumns(appState.data);
    processedData.data = processedData.data.slice(0, PREVIEW_ROW_LIMIT);
    appState.previewLength = processedData.data.length;

    const scrollTop = $(".wtHolder").scrollTop();
    const scrollLeft = $(".wtHolder").scrollLeft();
    let isFirstRender = false;

    $("#hot").empty();
    new Handsontable($("#hot").get(0), {
        data: processedData.data,
        colHeaders: applyCustomHeaders(processedData.fields),
        wordWrap: false,
        manualColumnResize: true,
        width: $(window).width() - 20,
        height: $(window).height() - $("#hot").get(0).getBoundingClientRect().y,
        afterRender: function() {
            if (!isFirstRender) {
                isFirstRender = true;
                $(".wtHolder").scrollTop(scrollTop);
                $(".wtHolder").scrollLeft(scrollLeft);
            }
        },
        modifyColWidth: function(width, col) {
            return width > 300 ? 300 : width;
        },
        afterGetColHeader: function(col, TH) {
            if (col === -1) return;

            if ($(TH).children().length > 1) {
                $(".hot-header", TH).remove();
            } else {
                $(TH).click(function() {
                    const self = this;
                    setTimeout(() => $(".header-input", self).trigger("focus"), 20);
                });
            }

            const headerContainer = $("<div>", { class: "hot-header" });
            const headerInput = $("<div>", { class: "header-input", contenteditable: "true" });

            const originalField = processedData.fields[col];
            headerInput.text(appState.config.headers[originalField] || TH.firstChild.textContent);

            $(TH).append(headerContainer);
            headerContainer.append(headerInput);
            headerContainer.append($("<span>", {
                class: "glyphicon glyphicon-remove remove-column",
                style: "padding-top: 2.5px"
            }).click(() => {
                appState.config.deletedFields[originalField] = true;
                saveConfigToLocalStorage();
                $("#resetColumns").show();
                renderPreviewTable();
            }));

            headerInput.get(0).addEventListener("input", () => {
                appState.config.headers[originalField] = headerInput.text();
                saveConfigToLocalStorage();
            });
            TH.firstChild.style.display = "none";
        },
        beforeOnCellMouseDown: function(event, coords, TD) {
            if (coords.row < 0) {
                event.stopImmediatePropagation();
            }
        }
    });
}

function saveConfigToLocalStorage() {
    localStorage.setItem(appState.configName, JSON.stringify(appState.config));
}

function showTimeoutError() {
    $("#waitHeader").hide();
    displayMessage("Error! Please ensure you are logged into FMS or reload the FMS page first.", "noResponseErr", false, true);
}

function getNextButtonSelectorFromStorage() {
    return localStorage.getItem("nextSelector:" + appState.hostName);
}

function processInitialTableData(data, isFirstLoad) {
    if (!data) {
        if (tabInfo.reloaded) {
            showTimeoutError();
        } else {
            tabInfo.reloaded = true;
            chrome.tabs.reload(tabInfo.id, {}, () => {
                chrome.tabs.onUpdated.addListener(function onTabUpdate(tabId, changeInfo) {
                    if (changeInfo.status === 'complete' && tabId === tabInfo.id) {
                        chrome.tabs.onUpdated.removeListener(onTabUpdate);
                        findInitialTables();
                    }
                });
            });
        }
        return;
    }

    appState = {
        ...appState,
        tableId: data.tableId,
        scraping: false,
        failedToProcess: false,
        processingError: null,
        tableSelector: data.tableSelector,
        startingUrl: data.href,
        hostName: data.hostname,
        previewLength: 0
    };
    appState.configName = data.hostname + "-config";
    appState.config = JSON.parse(localStorage.getItem(appState.configName)) || { headers: {}, deletedFields: {}, crawlDelay: 1000, maxWait: 20000 };
    
    tryCatch(() => {
        isFirstLoad 
            ? analytics.firePageViewEvent(appState.hostName, appState.startingUrl)
            : analytics.fireEvent("AnotherTable", { hostName: appState.hostName, startingUrl: appState.startingUrl });
    });
    
    if (Object.keys(appState.config.deletedFields).length) {
        $("#resetColumns").show();
    }
    
    const filename = getFilenameFromUrl(tabInfo.url);
    $("#wrongTable").show();
    
    if (appState.config.infinateScrollChecked) {
        $("#nextButton").hide();
        $("#startScraping").show();
        $("#infinateScroll").prop("checked", true);
    }
    
    chrome.tabs.sendMessage(tabInfo.id, { action: "getTableData" }, (response) => {
        if (!response || response.error) {
            displayMessage("Something went wrong!", "noResponseErr", true);
            return;
        }
        
        if (response.tableId !== appState.tableId) return;
        
        if (response.failedToProcess) {
            displayMessage("Failed to process rows on server. Showing raw data instead.", "error", false);
            appState.failedToProcess = true;
            appState.processingError = response.processingError;
        } else {
            $("#error").hide();
            appState.failedToProcess = false;
        }
        
        if (!appState.pages && !appState.config.infinateScrollChecked) {
            $("#nextButton").show();
        }
        
        if (!appState.pages) {
            appState.nextSelector = getNextButtonSelectorFromStorage();
            if (appState.nextSelector) {
                chrome.tabs.sendMessage(tabInfo.id, { action: "markNextButton", selector: appState.nextSelector }, (res) => {
                    if (!res.error) $("#startScraping").show();
                });
            }
        }
        
        $("#wait").hide();
        // Modification: Check Version First -> Then Auth
        checkAppVersion();
        
        displayMessage('Jangan lupa untuk set tombol next sebelum mulai', "instructions");
        
        appState.data = response.data;
        appState.pages = 1;
        appState.lastRows = response.data.length;
        appState.tableSelector = response.tableSelector;
        appState.goodClasses = response.goodClasses;
        appState.workingTime = 0;
        
        updateStatsDisplay();
        $(".download-button").show();
        renderPreviewTable();
        
        $("#csv").off("click").click(() => {
            tryCatch(fireDownloadAnalytics);
            updateStats({ download: true });
            let csvData = prepareDataForDisplay(appState.data);
            csvData.data.forEach((row, rIdx) => {
                row.forEach((cell, cIdx) => {
                    if(Array.isArray(cell)) {
                        csvData.data[rIdx][cIdx] = Papa.unparse([cell], { quotes: true, escapeChar: '"' });
                    }
                });
            });
            saveAs(new Blob([Papa.unparse(csvData, { quotes: true, escapeChar: '"' })], { type: "application/octet-stream" }), filename + ".csv");
        });
        
        $("#xlsx").off("click").click(() => {
            tryCatch(fireDownloadAnalytics);
            updateStats({ download: true });
            const workbookData = createWorkbook(prepareDataForDisplay(appState.data), tabInfo.url.substring(0, 100));
            saveAs(new Blob([stringToArrayBuffer(workbookData)], { type: "application/octet-stream" }), filename + ".xlsx");
        });
        
        $("#copy").off("click").click(() => {
            tryCatch(fireDownloadAnalytics);
            updateStats({ download: true });
            copyToClipboard(Papa.unparse(prepareDataForDisplay(appState.data), { delimiter: "\t" }));
        });
    });
}

function getFilenameFromUrl(url) {
    const hostnameParts = new URL(url).hostname.split(".");
    return hostnameParts[0].includes("www") ? hostnameParts[1] : hostnameParts[0];
}

function copyToClipboard(text) {
    const listener = (e) => {
        e.preventDefault();
        if (e.clipboardData) {
            e.clipboardData.setData("text/plain", text);
        } else if (window.clipboardData) {
            window.clipboardData.setData("Text", text);
        }
    };
    window.addEventListener("copy", listener);
    document.execCommand("copy");
    window.removeEventListener("copy", listener);
}

function findInitialTables() {
    chrome.tabs.sendMessage(tabInfo.id, { action: "findTables", robots: robots }, (data) => {
        processInitialTableData(data, true);
    });
}

function isInfiniteScrollEnabled() {
    return $("#infinateScroll").is(":checked");
}

function appendDataAndDedupe(newData) {
    appState.data = appState.data.concat(newData);
    const uniqueSet = new Set(appState.data.map(e => JSON.stringify(e)));
    appState.data = Array.from(uniqueSet, e => JSON.parse(e));
}

function startScraping() {
    appState.gettingNext = false;
    appState.scraping = true;
    $("#startScraping").hide();
    $("#stopScraping").show();
    displayMessage("", "error");
    displayMessage("Tunggu ...", "instructions");
    if (isInfiniteScrollEnabled()) $("#infinateScrollElement").hide();

    let pageStartTime = new Date();

    (function scrapeNextPage() {
        const scrollHandler = (callback) => {
            chrome.tabs.sendMessage(tabInfo.id, { action: "scrollDown", selector: appState.tableSelector }, (response) => {
                if (response && response.error) {
                    return displayMessage("", "instructions"), displayMessage(response.error, response.errorId || "error", true);
                }
                $("#wrongTable").hide();
                callback();
            });
        };

        let clickHandler = (callback) => {
            chrome.tabs.sendMessage(tabInfo.id, { action: "clickNext", selector: appState.nextSelector }, (response) => {
                if (response && response.error) {
                    return displayMessage("", "instructions"), displayMessage(response.error, response.errorId, true);
                }
                $("#wrongTable").hide();
                callback();
            });
        };
        
        if (isInfiniteScrollEnabled()) {
            clickHandler = scrollHandler;
        }

        waitForNetworkIdle(() => {
            chrome.tabs.sendMessage(tabInfo.id, { action: "getTableData", selector: appState.tableSelector }, (data) => {
                if (!data) return;
                
                if (data.error) {
                    return displayMessage("", "instructions"), displayMessage(data.error, data.errorId || "error", true);
                }
                
                if (data.failedToProcess) {
                    displayMessage("Failed to process rows. Showing raw data instead.", "error", false);
                    appState.failedToProcess = true;
                    appState.processingError = data.processingError;
                } else {
                    $("#error").hide();
                    appState.failedToProcess = false;
                }
                
                appState.lastRows = data.data.length;
                appState.pages++;
                appState.workingTime += new Date() - pageStartTime;
                pageStartTime = new Date();
                
                appendDataAndDedupe(data.data);
                updateStatsDisplay();
                
                if (appState.previewLength < PREVIEW_ROW_LIMIT) {
                    renderPreviewTable();
                } else {
                    displayMessage("Tampilan table dibatasi, tapi proses tetap berjalan.", "previewLimit");
                }
                
                if (appState.scraping) scrapeNextPage();
            });
        }, clickHandler, tabInfo.id, appState.config.maxWait, 100, appState.config.crawlDelay, (callback) => {
            chrome.tabs.sendMessage(tabInfo.id, {}, (response) => {
                callback(response !== undefined);
            });
        });
    })();
}

function initializeEventHandlers() {
    $("#stopScraping").click(() => stopScraping());

    $("#crawlDelay").bind("propertychange change click keyup input paste", function() {
        const val = $(this).val();
        if (isNaN(val) || val < 0 || parseInt(val * 1000) >= appState.config.maxWait) {
            return displayMessage("Bad min waiting value", "inputError");
        }
        displayMessage("", "inputError");
        appState.config.crawlDelay = parseInt(val * 1000);
        saveConfigToLocalStorage();
    });

    $("#maxWait").bind("propertychange change click keyup input paste", function() {
        const val = $(this).val();
        if (isNaN(val) || parseInt(val * 1000) <= appState.config.crawlDelay) {
            return displayMessage("Bad max waiting value", "inputError");
        }
        displayMessage("", "inputError");
        appState.config.maxWait = parseInt(val * 1000);
        saveConfigToLocalStorage();
    });

    $("#resetColumns").click(() => {
        appState.config.deletedFields = {};
        saveConfigToLocalStorage();
        $("#resetColumns").hide();
        renderPreviewTable();
    });

    $("#infinateScroll").click(() => {
        if (appState.config.infinateScrollChecked) {
            appState.config.infinateScrollChecked = false;
            $("#nextButton").show();
            if (getNextButtonSelectorFromStorage()) {
                $("#startScraping").show();
            } else {
                $("#startScraping").hide();
            }
        } else {
            appState.config.infinateScrollChecked = true;
            $("#nextButton").hide();
            $("#startScraping").show();
        }
        saveConfigToLocalStorage();
    });
}

function stopScraping(message = null) {
    appState.scraping = false;
    $("#startScraping").show();
    $("#stopScraping").hide();
    displayMessage("Selesai! Klik Copy atau Download sesuai dengan format yang dibutuhkan.", "instructions");
}

function showRatingRequest() {
    $("#pleaseRate").show();
    $("#rateLater").show().click(() => {
        updateStats({ rate: "later" });
        $("#pleaseRate").hide();
        tryCatch(() => analytics.fireEvent("Click", { button: "Rate later" }));
    });
    $("#rate").show().click(() => {
        updateStats({ rate: "now" });
        $("#pleaseRate").hide();
        tryCatch(() => analytics.fireEvent("Click", { button: "Rate now" }));
        chrome.tabs.create({ url: "#" });
    });
}

function updateStats(event) {
    let stats = JSON.parse(localStorage.getItem("stats")) || { pages: 0, rows: 0, downloads: 0, tabs: 0, lastRateRequest: null, lastDownloads: 0, lastRows: 0, rated: false };
    
    if (event.download) {
        stats.downloads++;
    } else if (event.rate) {
        if (event.rate === 'later') {
            stats.lastRateRequest = new Date().getTime();
            stats.lastDownloads = stats.downloads;
            stats.lastRows = stats.rows;
        }
        if (event.rate === 'now') {
            stats.rated = true;
        }
    } else {
        if (appState.pages === 1) stats.tabs++;
        stats.pages++;
        stats.rows += appState.lastRows;
    }
    
    if (!stats.rated && (new Date().getTime() - stats.lastRateRequest) > 5270400000 && (stats.downloads - stats.lastDownloads) > 9 && (stats.rows - stats.lastRows) > 999) {
        showRatingRequest();
    }
    
    localStorage.setItem("stats", JSON.stringify(stats));
}

function updateStatsDisplay() {
    $("#stats").empty()
        .append($("<div>", { text: "Pages : " + appState.pages }))
        .append($("<div>", { text: "Rows collected: " + appState.data.length }))
        .append($("<div>", { text: "Rows from last page: " + appState.lastRows }))
        .append($("<div>", { text: "Working time: " + parseInt(appState.workingTime / 1000) + "s" }));
    updateStats({});
}

async function generateSelectorsForFields(includeDeleted = false) {
    const tableSelector = appState.tableSelector.replace(".tablescraper-selected-table", "");
    let rowSelectors = [];
    appState.goodClasses.map(group => group.split(" ").map(cls => "." + cls).join(""))
        .forEach(selector => {
            selector = selector.replace(/.tablescraper-selected-row/g, "");
            if (selector.length) {
                rowSelectors.push(`${tableSelector} ${selector}:not(:empty)`);
            }
        });

    if (!rowSelectors.length) {
        rowSelectors.push(`${tableSelector} > *:not(:empty)`);
    }

    const baseRowSelector = rowSelectors.join(",");
    const fieldSelectors = [];
    let fieldNames = appState.names;
    if (includeDeleted) {
        fieldNames = fieldNames.concat(Object.keys(appState.config.deletedFields));
    }

    for (const name of fieldNames) {
        const paths = appState.namePaths[name];
        let fieldData = { target: "text", param: "" };
        fieldData.field_id = appState.config.headers[name] || name;

        let selectors = [];
        for (const path of paths) {
            let selector = "";
            try {
                selector = await chooseSelectorFromPath(baseRowSelector, path);
            } catch (e) {
                console.log(e);
            }
            selectors.push(selector);
            
            const pathParts = path.split(" ");
            if (pathParts.includes("href")) {
                fieldData.target = "prop";
                fieldData.param = "href";
            }
            if (pathParts.includes("src")) {
                fieldData.target = "prop";
                fieldData.param = "src";
            }
        }
        fieldData.selector = selectors.join(",");
        fieldSelectors.push(fieldData);
    }
    return [baseRowSelector, fieldSelectors];
}

function chooseSelectorFromPath(rowSelector, path) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabInfo.id, { action: "chooseSelector", rowSelector: rowSelector, path: path }, (response) => {
            response ? resolve(response.selector) : reject(new Error("Could not choose selector!"));
        });
    });
}

initializeApp();

$("#wrongTable").click(() => {
    $("#hot").empty();
    chrome.tabs.sendMessage(tabInfo.id, { action: "nextTable" }, processInitialTableData);
});

$("#nextButton").click(() => {
    displayMessage('Mark "Next" button or link', "instructions");
    appState.gettingNext = true;
    (function pollForNextButton() {
        chrome.tabs.sendMessage(tabInfo.id, { action: "getNextButton" }, (response) => {
            if (appState.scraping) return;
            if (appState.gettingNext) pollForNextButton();
            if (response.selector) {
                $("#startScraping").show();
                displayMessage('"Next" button located. Press start or mark another button.', "instructions");
                appState.nextSelector = response.selector;
                localStorage.setItem("nextSelector:" + appState.hostName, response.selector);
            }
        });
    })();
});

$("#startScraping").click(startScraping);

// --- VERSION CHECK LOGIC ---

// Helper: Semantic Version Compare (e.g., 1.2.0 > 1.1.9)
function compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    const len = Math.max(parts1.length, parts2.length);

    for (let i = 0; i < len; i++) {
        const a = parts1[i] || 0;
        const b = parts2[i] || 0;
        if (a > b) return 1; // v1 is greater
        if (a < b) return -1; // v2 is greater
    }
    return 0; // Equal
}

async function checkAppVersion() {
    try {
        const localVersion = chrome.runtime.getManifest().version;
        // Fetch remote version (plain text)
        const response = await fetch(VERSION_URL, { cache: "no-store" });
        if (!response.ok) throw new Error("Check failed");
        
        const remoteVersion = (await response.text()).trim();

        console.log(`Version Check: Local(${localVersion}) vs Remote(${remoteVersion})`);

        if (compareVersions(remoteVersion, localVersion) > 0) {
            // Remote is newer -> SHOW BLOCKER
            $("#remote-version-text").text(remoteVersion);
            $("#local-version-text").text(localVersion);
            $("#update-overlay").removeClass("d-none");
            
            // Hide loading if it's still there
            $("#wait").hide();
            
            // Disable interactions with main app just in case
            $("#app-view").addClass("d-none");
            $("#login-view").addClass("d-none");
        } else {
            // Version OK -> Proceed to Auth
            checkAuthStatus();
        }

    } catch (e) {
        console.warn("Version check skipped:", e);
        // On error (offline/fetch fail), proceed normally
        checkAuthStatus();
    }
}

// --- HELPER: Parse Date (Handles DD-MM-YYYY or ISO) ---
function parseDate(dateStr) {
    if (!dateStr) return new Date(0); // Return epoch if undefined
    
    // Check for DD-MM-YYYY format using Regex
    if (dateStr.match(/^\d{2}-\d{2}-\d{4}$/)) {
        const [day, month, year] = dateStr.split('-').map(Number);
        // Date constructor: year, monthIndex (0-11), day
        return new Date(year, month - 1, day);
    }
    
    // Fallback to standard date parser
    return new Date(dateStr);
}

// --- AUTHENTICATION LOGIC (AUTO LOGOUT & VALIDATION) ---

// 1. Check Auth State on Load (REAL-TIME SERVER VALIDATION)
async function checkAuthStatus() {
    const session = JSON.parse(localStorage.getItem(AUTH_KEY));
    
    // Jika tidak ada session lokal, langsung minta login
    if (!session || !session.username) {
        showLoginInterface();
        return;
    }

    // --- CHECK AUTO LOGOUT (6 HOURS) ---
    if (session.loginTime) {
        const loginTime = new Date(session.loginTime);
        const now = new Date();
        const diffMs = now - loginTime;
        // 6 jam dalam milidetik = 6 * 60 * 60 * 1000 = 21600000
        const MAX_SESSION_DURATION = 6 * 60 * 60 * 1000; 

        if (diffMs > MAX_SESSION_DURATION) {
            handleLogout("Sesi berakhir (6 jam). Silakan login kembali.");
            return;
        }
    } else {
        // Jika tidak ada loginTime di session lama, paksa logout untuk set ulang
        handleLogout("Sesi kadaluarsa.");
        return;
    }

    try {
        // Validasi ke Server secara Background
        const response = await fetch(DB_URL, { cache: "no-store" });
        if (!response.ok) throw new Error("Offline or DB Error");
        
        const users = await response.json();
        
        // Cari user yang sesuai dengan username & password di session
        const user = users.find(u => u.username === session.username && u.password === session.password);

        if (user) {
            // User valid, sekarang cek Expiry Date terbaru dengan parser
            const today = new Date();
            // Reset jam today ke 00:00:00 agar perbandingan tanggal adil
            today.setHours(0,0,0,0);
            
            const expiryDate = parseDate(user.expiry);
            
            if (expiryDate >= today) {
                // MASIH AKTIF: Update data lokal dengan data server
                const newSession = {
                    ...session,
                    expiry: user.expiry,
                    type: user.type,
                    avatar: user.avatar
                };
                localStorage.setItem(AUTH_KEY, JSON.stringify(newSession));
                
                // Lanjut masuk aplikasi
                showAppInterface(newSession);
            } else {
                // SUDAH EXPIRED
                const day = String(expiryDate.getDate()).padStart(2, '0');
                const month = String(expiryDate.getMonth() + 1).padStart(2, '0');
                const year = expiryDate.getFullYear();
                handleLogout("Masa aktif akun telah habis pada " + `${day}-${month}-${year}`);
            }
        } else {
            // Username tidak ditemukan ATAU Password salah
            handleLogout("Sesi tidak valid atau password telah diubah.");
        }

    } catch (error) {
        console.warn("Server validation failed (Offline?), checking local...", error);
        
        // Fallback: Jika offline, gunakan data lokal saja
        const today = new Date();
        today.setHours(0,0,0,0);
        const localExpiry = parseDate(session.expiry);
        
        if (localExpiry >= today) {
            showAppInterface(session);
        } else {
            handleLogout("Sesi lokal telah berakhir.");
        }
    }
}

// 2. Login Function (UPDATED: Save Password for Re-validation)
async function handleLogin() {
    const usernameInput = $("#username-input").val().trim();
    const passwordInput = $("#password-input").val().trim();
    const errorMsg = $("#login-error");
    const loginBtn = $("#btn-login");

    errorMsg.hide();

    if (!usernameInput || !passwordInput) {
        errorMsg.text("Please enter both username and password.").show();
        return;
    }

    // Set UI to loading state
    loginBtn.text("Validating...").prop("disabled", true);

    try {
        // Fetch users from GitHub Raw JSON
        const response = await fetch(DB_URL, { cache: "no-store" });
        if (!response.ok) throw new Error("Database inaccessible");
        
        const users = await response.json();
        
        // Check Credentials
        const user = users.find(u => u.username === usernameInput && u.password === passwordInput);

        if (user) {
            const today = new Date();
            today.setHours(0,0,0,0);
            
            const expiryDate = parseDate(user.expiry);
            
            if (expiryDate >= today) {
                // Success: Save Session with Profile Data AND Password
                const sessionData = {
                    username: user.username,
                    password: user.password, // Saved for background validation
                    expiry: user.expiry,
                    type: user.type,   
                    avatar: user.avatar, 
                    loginTime: new Date().toISOString() // Simpan waktu login saat ini
                };
                localStorage.setItem(AUTH_KEY, JSON.stringify(sessionData));
                
                // Show App
                showAppInterface(sessionData);
            } else {
                const day = String(expiryDate.getDate()).padStart(2, '0');
                const month = String(expiryDate.getMonth() + 1).padStart(2, '0');
                const year = expiryDate.getFullYear();
                errorMsg.text("Account expired on " + `${day}-${month}-${year}`).show();
            }
        } else {
            errorMsg.text("Invalid username or password.").show();
        }

    } catch (error) {
        console.error("Login Error:", error);
        errorMsg.text("Connection error. Please check your internet.").show();
    } finally {
        loginBtn.text("SIGN IN").prop("disabled", false);
    }
}

// 3. Logout Function
function handleLogout(msg = "") {
    localStorage.removeItem(AUTH_KEY);
    showLoginInterface();
    if(msg) $("#login-error").text(msg).show();
}

// 4. UI Switchers
function showLoginInterface() {
    $("#app-view").addClass("d-none");
    $("#login-view").removeClass("d-none");
    // Clear inputs
    $("#username-input").val("");
    $("#password-input").val("");
}

function showAppInterface(userSession) {
    $("#login-view").addClass("d-none");
    $("#app-view").removeClass("d-none");
    
    // Update Profile Info
    $("#user-display-name").text(userSession.username);
    $("#user-role-badge").text(userSession.type || "Basic User");
    
    // Format Date to DD-MM-YYYY using the parser to be safe
    const dateObj = parseDate(userSession.expiry);
    const day = String(dateObj.getDate()).padStart(2, '0');
    const month = String(dateObj.getMonth() + 1).padStart(2, '0'); 
    const year = dateObj.getFullYear();
    const formattedDate = `${day}-${month}-${year}`;
    
    $("#user-expiry-date").text("Expires: " + formattedDate);

    // --- NEW: Calculate Days Remaining ---
    const today = new Date();
    today.setHours(0, 0, 0, 0); 
    
    const timeDiff = dateObj.getTime() - today.getTime();
    const daysRemaining = Math.ceil(timeDiff / (1000 * 3600 * 24));
    
    const daysElem = $("#user-days-remaining");
    
    if (daysRemaining > 0) {
        daysElem.text(`(${daysRemaining} hari lagi)`);
        
        daysElem.removeClass("warning danger");
        if (daysRemaining <= 3) {
            daysElem.addClass("danger");
        } else if (daysRemaining <= 7) {
            daysElem.addClass("warning");
        }
    } else if (daysRemaining === 0) {
        daysElem.text("(Berakhir hari ini!)").addClass("danger");
    } else {
        daysElem.text("(Expired)").addClass("danger");
    }

    // Apply Special Effects for High-Rank Roles
    const specialRoles = ["Administrator", "Lord"];
    if (specialRoles.includes(userSession.type)) {
        $("#user-role-badge").addClass("role-special");
        $("#user-avatar-img").addClass("avatar-glowing");
        
        // Add Crown Effect to Wrapper
        // Karena elemen wrapper tidak punya ID unik di HTML saya tadi (hanya class), 
        // kita cari parent dari image atau tambahkan ID di HTML. 
        // Di sini saya pakai traversing jQuery agar aman.
        $("#user-avatar-img").parent().addClass("special-user");
        
        // Remove manual particle injection as CSS handles text glow now
        $(".role-particles").remove(); 
    } else {
        $("#user-role-badge").removeClass("role-special");
        $("#user-avatar-img").removeClass("avatar-glowing");
        $("#user-avatar-img").parent().removeClass("special-user");
    }
    
    // Set Avatar - Direct Link Logic
    let avatarUrl = userSession.avatar;
    if (!avatarUrl || avatarUrl.trim() === "") {
         avatarUrl = "https://ui-avatars.com/api/?name=" + userSession.username;
    }
    
    $("#user-avatar-img").attr("src", avatarUrl);
    
    // Trigger resize to fix table layout
    setTimeout(() => {
        $(window).trigger('resize');
        renderPreviewTable();
    }, 200);
}

// 5. Event Listeners
$(document).ready(() => {
    // Tampilkan Versi Aplikasi di UI
    const appVersion = chrome.runtime.getManifest().version;
    $(".app-version").text(`v${appVersion}`);

    $("#btn-login").click(handleLogin);
    $("#btn-logout").click(() => handleLogout());
    $("#btn-update-now").click(() => {
        chrome.tabs.create({ url: UPDATE_PAGE_URL });
    });
    
    // Allow Enter key to submit login
    $("#password-input, #username-input").on('keypress', function (e) {
        if (e.which === 13) {
            handleLogin();
        }
    });
});