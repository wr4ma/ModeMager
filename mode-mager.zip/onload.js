let foundTables = [];
let selectedTableIndex = 0;
const MAX_TABLES_TO_FIND = 5;
let nextButtonClickHandler;
let nextButtonMouseEnterHandler;

function analyzeElementChildren(parentElement) {
    const children = $(parentElement).children();
    const classCounts = {};
    const classGroupCounts = {};

    children.each(function () {
        if (["script", "img", "meta", "style"].includes(this.nodeName.toLowerCase())) {
            return;
        }
        if ($(this).text().trim().length === 0) {
            return;
        }

        const classes = getElementClasses($(this)).sort();
        const classGroup = classes.join(" ");

        classGroupCounts[classGroup] = (classGroupCounts[classGroup] || 0) + 1;

        classes.forEach(cls => {
            classCounts[cls] = (classCounts[cls] || 0) + 1;
        });
    });

    const minRequired = children.length / 2 - 2;

    let goodClassGroups = Object.keys(classGroupCounts).filter(group => classGroupCounts[group] >= minRequired);

    if (goodClassGroups.length === 0) {
        goodClassGroups = Object.keys(classCounts).filter(cls => classCounts[cls] >= minRequired);
    }

    const isLargeContainer = $(parentElement).width() * $(parentElement).height() > 50000;
    if (isLargeContainer && children.length && (!goodClassGroups.length || (goodClassGroups.length === 1 && goodClassGroups[0] === ""))) {
        return {
            children: children.filter(function () {
                if (!this.nodeName) {
                    console.log("Invalid element found:", this);
                    return false;
                }
                const nodeName = this.nodeName.toLowerCase();
                const hasText = !!$(this).text().trim().length;
                return !["script", "img", "meta", "style"].includes(nodeName) && hasText;
            }),
            goodClasses: []
        };
    }

    return {
        children: children.filter(function () {
            let isGoodChild = false;
            const $this = $(this);
            goodClassGroups.forEach(group => {
                isGoodChild |= hasAllClasses($this, group);
            });
            return isGoodChild;
        }),
        goodClasses: goodClassGroups
    };
}

function findTables() {
    const bodyArea = $("body").width() * $("body").height();
    const potentialTables = [];

    $("body *").each(function () {
        const area = this.offsetWidth * this.offsetHeight;
        if (isNaN(area) || area < 0.02 * bodyArea) {
            return;
        }

        const analysis = analyzeElementChildren(this);
        const children = analysis.children;
        const childCount = children.length;

        if (isNaN(childCount) || childCount < 3) {
            return;
        }

        const score = area * childCount * childCount;
        potentialTables.push({
            table: this,
            goodClasses: analysis.goodClasses,
            area: area,
            children: children,
            text: children.text(),
            score: score,
            selector: generateElementSelector(this),
            type: "selector"
        });
    });

    foundTables = potentialTables.sort((a, b) => b.score - a.score).slice(0, MAX_TABLES_TO_FIND);
    console.log("findTables found:", foundTables);
}

async function getTableData(callback, selector) {
    if (selector) {
        const tableElement = findLenientElement(selector);
        console.log("getTableData using provided selector:", selector, tableElement);

        if (!tableElement) {
            console.log("Provided table selector not found.");
            return callback({ error: "Table not found" });
        }

        if (foundTables.length === 0) {
            foundTables.push({});
        }

        const analysis = analyzeElementChildren(tableElement);
        const rows = analysis.children;

        if (isPageAlreadyVisited(rows.text())) {
            console.log("Done! Data on this page has already been scraped.");
            return callback({ error: "If the page did not change, try increasing the 'Min Delay'.", errorId: "finished" });
        }

        foundTables[selectedTableIndex] = {
            ...foundTables[selectedTableIndex],
            table: tableElement,
            children: rows,
            goodClasses: analysis.goodClasses,
            text: rows.text()
        };

        markPageAsVisited(rows.text());
        highlightSelectedTable();
        return getTableData(callback);
    }

    const extractedData = [];
    const currentTable = foundTables[selectedTableIndex];

    if (!currentTable || !currentTable.children) {
        return callback({ error: "No table selected or table has no children." });
    }

    currentTable.children.each(function () {
        const rowData = {};
        const pathParts = [];

        function traverseRow(element, path, node) {
            if (!node.nodeName) {
                console.log("Invalid node encountered during traversal:", node);
                return;
            }

            const currentPath = `${path}/${node.nodeName.toLowerCase()}${getElementClasses(element).map(c => "." + c).join("")}`;
            pathParts.push(currentPath);

            const text = getOwnText(element).trim();
            const href = element.prop("href");
            const src = element.prop("src");

            setData(currentPath, text);
            setData(currentPath, href, "href");
            setData(currentPath, src, "src");

            element.children().each(function () {
                traverseRow($(this), currentPath, this);
            });
        }

        function setData(baseKey, value, suffix) {
            if (!value) return;

            let key = baseKey + (suffix ? ` ${suffix}` : "");
            let finalKey = key;
            let counter = 0;

            pathParts.forEach(p => {
                if (p === baseKey) counter++;
            });

            if (counter > 1) {
                finalKey = `${key} ${counter}`;
            }
            rowData[finalKey] = value;
        }

        traverseRow($(this), "", this);

        if (Object.keys(rowData).length) {
            extractedData.push(rowData);
        }
    });

    callback({
        data: extractedData,
        tableId: selectedTableIndex,
        tableSelector: currentTable.selector,
        goodClasses: currentTable.goodClasses,
    });
}

function highlightSelectedTable() {
    const tableInfo = foundTables[selectedTableIndex];
    if (!tableInfo) return;

    const prevIndex = (selectedTableIndex + foundTables.length - 1) % foundTables.length;
    const prevTableInfo = foundTables[prevIndex];
    if (prevTableInfo) {
        $(prevTableInfo.table).removeClass("tablescraper-selected-table");
        $(prevTableInfo.children).removeClass("tablescraper-selected-row");
    }

    $(tableInfo.table).addClass("tablescraper-selected-table");
    $(tableInfo.children).addClass("tablescraper-selected-row");
}

function clearAllHighlights() {
    $("*").removeClass("tablescraper-selected-table tablescraper-selected-row");
}

function enableNextButtonSelector(callback) {
    window.focus();

    nextButtonMouseEnterHandler = function (event) {
        if ($(this).is($(event.target))) {
            $("*").removeClass("tablescraper-hover");
            $(generateElementSelector(this)).last().addClass("tablescraper-hover");
        }
    };

    nextButtonClickHandler = function (event) {
        event.preventDefault();

        $("*").off("click", nextButtonClickHandler).off("mouseenter", nextButtonMouseEnterHandler);

        $(".tablescraper-hover").removeClass("tablescraper-hover");
        $(".tablescraper-next-button").removeClass("tablescraper-next-button");

        const selector = generateElementSelector(event.target);
        $(event.target).addClass("tablescraper-next-button");
        console.log("Next button selector:", selector);
        callback({ selector: selector });

        return false;
    };

    $("*").on("click", nextButtonClickHandler).on("mouseenter", nextButtonMouseEnterHandler);
}

function clickNextButton(selector, callback, markOnly = false) {
    const nextButton = findLenientElement(selector);

    if (nextButton) {
        nextButton.last().addClass("tablescraper-next-button");
        if (markOnly) {
            return callback({});
        }

        $("*").off("click", nextButtonClickHandler).off("mouseenter", nextButtonMouseEnterHandler);

        setTimeout(() => {
            callback({});
            simulateClick(nextButton.last()[0]);
        }, 100);

    } else {
        const errorData = markOnly ?
            { error: "Next button not found", errorId: "error" } :
            { error: "Done, no more 'next' buttons found. You can now download or copy the data.", errorId: "finished" };
        callback(errorData);
    }
}

function simulateClick(element) {
    const bounds = element.getBoundingClientRect();
    const clickEvent = (type) => new MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        view: window,
        detail: 1,
        screenX: bounds.left,
        screenY: bounds.top,
        clientX: bounds.left,
        clientY: bounds.top,
        ctrlKey: false,
        altKey: false,
        shiftKey: false,
        metaKey: false,
        button: 0,
        relatedTarget: null
    });

    element.dispatchEvent(clickEvent("mousedown"));
    element.dispatchEvent(clickEvent("click"));
    element.dispatchEvent(clickEvent("mouseup"));
}

async function scrollToLoadMore(selector, callback) {
    const checkScrollPosition = (el) => new Promise(resolve => {
        if (el.scrollTop + 5 >= el.scrollHeight - el.offsetHeight) {
            resolve(true);
        } else {
            el.scrollTop = el.scrollTop + 50;
            setTimeout(() => resolve(el.scrollTop + 5 >= el.scrollHeight - el.offsetHeight), 10);
        }
    });

    const doScroll = (el, amount) => new Promise(resolve => {
        el.scrollTop = el.scrollTop + amount;
        setTimeout(resolve, 1000);
    });

    let scrollableParent = document.querySelector(selector);
    while (scrollableParent) {
        if (await checkScrollPosition(scrollableParent)) break;
        scrollableParent = scrollableParent.parentElement;
    }

    if (!scrollableParent) {
        return callback({ error: "No element with a scrollbar found" });
    }
    console.log("Found element with scrollbar:", scrollableParent);

    let contentChanged = false;
    let scrollStalled = false;
    let initialChildCount = $(selector).children().length;
    let lastScrollTop = scrollableParent.scrollTop;

    while (!contentChanged && !scrollStalled) {
        await doScroll(scrollableParent, 1000);
        contentChanged = initialChildCount !== $(selector).children().length;
        scrollStalled = scrollableParent.scrollTop === lastScrollTop;
        lastScrollTop = scrollableParent.scrollTop;
    }

    callback({});
}

function hashString(text) {
    const hash = sha256.create();
    hash.update(text);
    return hash.hex();
}

function isPageAlreadyVisited(pageText) {
    const visitedStr = localStorage.getItem("visited");
    if (visitedStr === null) return false;

    const visitedHashes = JSON.parse(visitedStr);
    const currentHash = hashString(pageText);

    return visitedHashes[visitedHashes.length - 1] === currentHash ||
        visitedHashes[visitedHashes.length - 2] === currentHash;
}

function markPageAsVisited(pageText) {
    let visitedHashes = JSON.parse(localStorage.getItem("visited")) || [];
    visitedHashes.push(hashString(pageText));
    localStorage.setItem("visited", JSON.stringify(visitedHashes));
}

function getElementClasses($element) {
    const classAttr = $element.attr("class") || "";
    return classAttr.trim().split(/\s+/).filter(cls => cls.length > 0);
}

function hasAllClasses($element, classString) {
    const classes = classString.split(" ");
    for (let i = 0; i < classes.length; i++) {
        if (! $element.hasClass(classes[i])) {
            return false;
        }
    }
    return true;
}

function getOwnText($element) {
    return $element.clone().children().remove().end().text();
}

function generateElementSelector(element) {
    return $(element)
        .parents()
        .addBack()
        .not("html")
        .not("body")
        .map(function () {
            let selectorPart = this.tagName.toLowerCase();
            if (this.id && !this.id.match(/\d+/g)) {
                selectorPart += "#" + escapeCssSelector(this.id, "");
            } else if (this.className && typeof this.className === "string") {
                const classes = this.className.trim().replace(/\s+/g, ".");
                if (classes) {
                    selectorPart += "." + escapeCssSelector(classes, "");
                }
            }
            return selectorPart;
        })
        .get()
        .join(">");
}

function escapeCssSelector(str, prefix = ".") {
    const escaped = str.replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\$&").trim();
    return prefix + escaped;
}

function findLenientElement(selector) {
    while (selector.length) {
        const $element = $(selector);
        if ($element.length) {
            return $element;
        }
        selector = selector.split(">").slice(1).join(">");
    }
    return null;
}

function getPageHtml(callback) {
    let html = document.documentElement.innerHTML;
    html = html.replace(/<\/?(!--)?(html|body|StartFragment|EndFragment)-*>/g, "");
    callback({ html });
}

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    switch (message.action) {
        case "findTables":
            foundTables = [];
            findTables();
        case "nextTable":
            if (foundTables.filter(t => !t.robot).length === 0) {
                findTables();
            }
            selectedTableIndex = (selectedTableIndex + 1) % foundTables.length;
            highlightSelectedTable();
            localStorage.removeItem("visited");
            sendResponse({
                tableId: selectedTableIndex,
                tableSelector: foundTables[selectedTableIndex]?.selector,
                href: window.location.href,
                hostname: window.location.hostname
            });
            break;

        case "getTableData":
            getTableData(sendResponse, message.selector);
            break;

        case "getNextButton":
            enableNextButtonSelector(sendResponse);
            break;

        case "clickNext":
            clickNextButton(message.selector, sendResponse, false);
            break;

        case "markNextButton":
            clickNextButton(message.selector, sendResponse, true);
            break;

        case "scrollDown":
            clearAllHighlights();
            scrollToLoadMore(message.selector, sendResponse);
            break;
            
        default:
            sendResponse({});
            break;
    }

    return true;
});